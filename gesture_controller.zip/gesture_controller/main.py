from core.hand_recognition import HandRecog
from core.controller import Controller
from core.gesture_enums import Gest, HLabel
from utils.mediapipe_utils import classify_hands
import mediapipe as mp
import cv2

class GestureController:
    def start(self):
        print("Starting gesture controller...")

if __name__ == "__main__":
    gc1 = GestureController()
    gc1.start()
